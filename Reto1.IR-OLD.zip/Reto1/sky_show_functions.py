import check


def show_data_menu(data):
    while True:
        option = input("""
=== MENU 1: VER DATOS METEOROLÓGICOS ===
Seleccione una opción:
    1. Mostrar ubicaciones
    2. Mostrar información de una ubicación
    0. Regresar o salir
                       
""")
        if option == "1":
            print(f"\nLas ubicaciones disponibles para consultar son: ")
            locations = get_all_locations(data)
            print(locations)

        elif option == "2":
            country_option = input("Escriba el país a consultar: ")
            locations = get_all_locations(data)
            if check.is_in_list(locations, country_option):
                measurements = get_weather_data_of_country(
                    data, country_option)
                for measurement in measurements:
                    print(f"""
Fecha: {measurement['date']}
Temperatura: {measurement['temperature']}
Humedad: {measurement['humidity']}
Velocidad del viento: {measurement['wind_speed']}
""")
                print(f"""
--> Se encontraron {len(measurements)} mediciones disponibles para {country_option.upper()}
""")
            else:
                print(f"""
*** Ese país no está en la lista
Los países disponibles son:
{locations}""")

        elif option == "0" or option.lower() == "salir":
            break

        else:
            print("*** Por favor elija sólo una de las opciones disponibles.")


def get_all_locations(data):
    countries = []
    for location in data:
        country = location["location_name"]
        countries.append(country)
    return countries


def get_weather_data_of_country(data, country_name):
    country_measurements = []
    for country_data in data:
        if country_data["location_name"].lower() == country_name.lower():
            for measurement in country_data["location_measurements"]:
                country_measurements.append(measurement)
    return country_measurements


def get_weather_variables(data):
    variables = set()  # Usamos un conjunto para evitar duplicados
    for location in data:
        for measurement in location["location_measurements"]:
            variables.update(measurement.keys())
    if "date" in variables:
        variables.remove("date")

    return list(variables)
